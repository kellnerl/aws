docker-compose run web /bin/bash
