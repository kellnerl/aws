#!/bin/bash
docker exec -it diskuze-container /bin/bash
