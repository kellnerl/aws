# diskuse-django
web aplikace pro diskutování nad články na webu# diskuse-django
